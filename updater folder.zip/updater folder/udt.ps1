Add-Type -assembly System.Windows.Forms
Add-Type -AssemblyName PresentationFramework
## -- Create The Progress-Bar
$ObjForm = New-Object System.Windows.Forms.Form
$ObjForm.Text = "HotDocs Sidebar Updater."
$ObjForm.BackColor = "White"
$ObjForm.Width = 400
$ObjForm.Height = 150
$ObjForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedSingle
$ObjForm.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen

## -- Create The Label
$ObjLabel = New-Object System.Windows.Forms.Label
$ObjLabel.Text = "Downloading update. Please wait ... "
$ObjLabel.Left = 5
$ObjLabel.Top = 10
$ObjLabel.Width = 500 - 20
$ObjLabel.Height = 15
$ObjLabel.Font = "Tahoma"
## -- Add the label to the Form
$ObjForm.Controls.Add($ObjLabel)

$PB = New-Object System.Windows.Forms.ProgressBar
$PB.Name = "PowerShellProgressBar"
$PB.Value = 0
$PB.Style="Continuous"

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 300
$System_Drawing_Size.Height = 20
$PB.Size = $System_Drawing_Size
$PB.Left = 50
$PB.Top = 40
$ObjForm.Controls.Add($PB)

## -- Show the Progress-Bar and Start The PowerShell Script
$ObjForm.Show() | Out-Null
$ObjForm.Focus() | Out-NUll
$ObjLabel.Text = "Downloading update. Please wait ... "
$ObjForm.Refresh()

Start-Sleep -Seconds 1

$PB.Value = 10
py -m pip install keyboard
Start-Sleep -s 4

$PB.Value = 50

$ObjLabel.Text = "Installing update. Please wait ... "
Start-Sleep -s 10

$PB.Value = 80
py testing.py
$PB.Value = 90
Start-Sleep -s 5
$PB.Value = 100
$ObjForm.close()
$ObjLabel.Text = "HotDocs Sidebar successfully updated. Exiting... "
Write-Host "`n"
[System.Windows.MessageBox]::Show('HotDocs Sidebar updated successfully.')